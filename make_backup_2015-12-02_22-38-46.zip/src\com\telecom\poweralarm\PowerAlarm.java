package com.telecom.poweralarm;

import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;


public class PowerAlarm {

    String[][] allalarmtype={{},
            {"电源电池电压过低(1022)","电源整流模块告警(1021)","交流停电告警(1020)",
                    "二次电源(监测)告警(1001)","电源输出电压过高(1025)","电源负载熔丝中断(1023)",
                    "电源电池均充(1024)"},
            {"ONT备用电池电压过低","ONT备用电池无法充电","ONU电源掉电(FTTB类)",
                    "电池电压异常","整流模块异常","交流电压异常","直流电压异常"},
            {"ONU电源掉电(FTTB类)","ONU电源掉电(FTTH类)","ONU电源掉电",
                    "整流模块异常","ONU电源掉电(FTTB类)","ONU电源掉电(FTTH类)"},
            {"电池电压过低/数字量自定义告警10", "输入电压过高/数字量自定义告警8",
                    "整流模块故障/数字量自定义告警9", "整流模块故障/数字量与设定的有效值不符",
                    "电池均充/数字量自定义告警11", "输入电压过高/数字量自定义告警12",
                    "电池电压过低/数字量与设定的有效值不符", "电池电压过低/数字量自定义告警10"}
    };

    int[] missingflag={0};

    public  static void main(String[] args) throws UnsupportedEncodingException {

        String nameinems=null;
        String namemr;
        String equipmentname=null;
        String titletmp,infotmp;
        String alarminfo;

        Pattern patternipsu=Pattern.compile(".*IPSU.*");
        Pattern patternma=Pattern.compile(".*MA5680.*");
        Pattern patternzte=Pattern.compile(".*C\\d{3}.*");
        Pattern patternua=Pattern.compile(".*UA5000.*");


        Connection con=null;
        Connection condev=null;
        Connection conalarm=null;

        Statement statedev=null;
        Statement statealarm=null;
        Statement state=null;
        ResultSet resbyselforalldev=null;
        ResultSet resbyselforallalarm=null;
        int devtype=0;

        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();

            con= DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/PowerAlarm?useUnicode=true&characterEncoding=gbk",
                    "root","60528678czj");
            //conalarm=condev=con;

            if(!con.isClosed())
                System.out.println("MySQL connected successfully!");

            statedev=con.createStatement();
            statealarm=con.createStatement();
            state=con.createStatement();
            resbyselforalldev=statedev.executeQuery("select * from alldevtest");
            resbyselforallalarm=statealarm.executeQuery("select * from accessallpoweralarm");
//

            PowerAlarm pa=new PowerAlarm();

            while(resbyselforalldev.next()){
                nameinems = resbyselforalldev.getString("nameinems");
                namemr=resbyselforalldev.getString("name");

                if(nameinems==null)
                    nameinems="";
                //System.out.println(namemr);
                devtype=0;
                if(patternipsu.matcher(nameinems).matches()) {devtype=1;}
                if(patternma.matcher(nameinems).matches())  { devtype=2;}
                if(patternzte.matcher(nameinems).matches())  devtype=3;
                if(patternua.matcher(nameinems).matches())   devtype=4;

                while (resbyselforallalarm.next()) {
                    //	System.out.println(devtype);
                    titletmp=resbyselforallalarm.getString("alarmtitle");
                    infotmp=resbyselforallalarm.getString("alarminfo");
                    equipmentname = resbyselforallalarm.getString("equipmentname");
                    if(titletmp==null) titletmp="";
                    if(infotmp==null)  infotmp="";
                    if(equipmentname==null)  equipmentname="";

                    alarminfo = titletmp.length()<infotmp.length()?resbyselforallalarm.getString("alarminfo"):resbyselforallalarm.getString("alarmtitle");
                    //	System.out.println(nameinems);
                    System.out.println(equipmentname);
                    //System.out.println(resbyselforallalarm.next());
                    //assert (nameinems.equals(equipmentname)):"no matches";
                    if (equipmentname.equalsIgnoreCase(nameinems)){
                        fuck("world");
                        pa.SearchMissingAlarm(devtype,alarminfo);

                    }
                }
                try{
                    pa.InsertAlarmWithMR(state,devtype,namemr,nameinems);
                }
                catch(SQLException e){
                    e.printStackTrace();
                }
                pa.ClearMissingFlag();
            }

        }
        catch(Exception e){
            System.out.println("MYSQL error:"+e.getMessage());
            e.printStackTrace();
        }
        finally{
            try {
                //释放资源
                statedev.close();
                resbyselforalldev.close();
                statealarm.close();
                resbyselforallalarm.close();
                state.close();
                con.close();
                System.out.println("Data is writed successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void InsertAlarmWithMR(Statement st,int dt,String mr,String dev)
            throws SQLException, UnsupportedEncodingException {
        if(dt!=0){
            if(!isMissAllAlarm()){
                for (int j=0;j<missingflag.length;j++){
                    if(missingflag[j]==0){
                        String sqlinsert = String.format("insert into PowerAlarm.mrdevalarm(mrname,devname,alarminfo) "
                                + "values(\"%s\",\"%s\",\"%s\")",mr,dev,allalarmtype[dt][j]);
                        st.executeUpdate(sqlinsert);
                        //System.out.println(allalarmtype[dt][j]);
                    }
                }
            }
            else{
                String missall="该设备缺失所有告警！";
                String sqlinsert = String.format("insert into PowerAlarm.mrdevalarm(mrname,devname,alarminfo) "
                        + "values(\"%s\",\"%s\",\"%s\")",mr,dev,missall);
                st.executeUpdate(sqlinsert);
                //System.out.println("该设备缺失所有告警！");
            }

        }
    }

    public void SearchMissingAlarm(int dt,String alarm) {
        for (int i = 0; i < allalarmtype[dt].length; i++) {
            if (alarm.equals(allalarmtype[dt][i])){
                missingflag[i] =1;
                System.out.println("hello");}
        }
    }

    public boolean isMissAllAlarm(){
        int count=0;
        for(int i=0;i<missingflag.length;i++){
            if(missingflag[i]==0){
                count++;
            }
        }
        return count==missingflag.length;
    }

    public void ClearMissingFlag(){
        for(int i=0;i<missingflag.length;i++){
            missingflag[i]=0;
        }
        //System.out.println("test");
    }

    public static void fuck(String str){
        System.out.println(str);
    }
    public static void fuck(int n){
        System.out.println(n);
    }
}